# LAST STAND ARENA — Multiplayer setup (alpha)

This bundle keeps the existing single-player game and adds a first online networking layer. Players connected to the same server can see each other's operator positions and names. Local bots, game sounds, save data, and modes remain local to each browser.

## Deploy the server to Render
1. Add `server.js` and `package.json` to the root of the same GitHub repository as `index.html`.
2. In Render choose **New + → Web Service**, connect the repository, and use:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
3. Use the free instance if offered, then deploy.
4. When deployed, open the service URL. It should show `LAST STAND ARENA multiplayer server is online.`

## Connect from the game
Deploy the updated `index.html` to your existing Netlify site. Start a match and click **CONNECT ONLINE**. Paste the Render service URL beginning with `https://`.

## Current alpha limits
This first pass synchronizes player presence and movement only; local bot AI, bullet damage, scores, and saves are still per-browser. It is not yet authoritative player-versus-player combat. The Render free service may sleep when idle, causing a delay on the first connection.
